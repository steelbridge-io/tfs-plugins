jQuery(document).ready(function($) {
    $("#your-profile .show-admin-bar").remove();
});