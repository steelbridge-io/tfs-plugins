<?php
/*
Plugin Name: Add Destination Role and Redirect
Description: Adds custom user roles called "Destination" and "Travel Manager" and redirects users with these roles to specific customizable posts upon login. Adds custom dashboard widgets with the link and title of the assigned private pages.
Version: 1.9
Author: Your Name
*/

// Adding custom roles
function add_custom_roles() {
	$roles = [
	'destination' => [
	'name' => 'Destination',
	'capabilities' => [
	'read' => true,
	'edit_posts' => false,
	'delete_posts' => false,
	'read_private_posts' => true,
	]
	],
	'travel_manager' => [
	'name' => 'Travel Manager',
	'capabilities' => [
	'read' => true,
	'edit_posts' => true,
	'delete_posts' => true,
	'publish_posts' => true,
	'edit_published_posts' => true,
	'edit_others_posts' => true,
	'delete_published_posts' => true,
	'delete_others_posts' => true,
	'read_private_posts' => true,
	'edit_pages' => true,
	'edit_others_pages' => true,
	'edit_published_pages' => true,
	'publish_pages' => true,
	'delete_pages' => true,
	'delete_others_pages' => true,
	'delete_published_pages' => true,
	'read_private_pages' => true,
	'gravityforms_edit_forms' => true,
	'gravityforms_delete_forms' => true,
	'gravityforms_create_form' => true,
	'gravityforms_view_entries' => true,
	'gravityforms_edit_entries' => true,
	'gravityforms_delete_entries' => true,
	'gravityforms_view_settings' => true,
	'gravityforms_edit_settings' => true,
	'gravityforms_export_entries' => true,
	'gravityforms_view_entry_notes' => true,
	'gravityforms_edit_entry_notes' => true,
	]
	],
	'tfs_staff' => [
	'name' => 'TFS Staff',
	'capabilities' => [
	'read' => true,
	'edit_posts' => false,
	'delete_posts' => false,
	'publish_posts' => false,
	'edit_published_posts' => false,
	'edit_others_posts' => false,
	'delete_published_posts' => false,
	'delete_others_posts' => false,
	'read_private_posts' => true,
	'edit_pages' => false,
	'edit_others_pages' => false,
	'edit_published_pages' => false,
	'publish_pages' => false,
	'delete_pages' => false,
	'delete_others_pages' => false,
	'delete_published_pages' => false,
	'read_private_pages' => true,
	'gravityforms_edit_forms' => false,
	'gravityforms_delete_forms' => false,
	'gravityforms_create_form' => false,
	'gravityforms_view_entries' => false,
	'gravityforms_edit_entries' => false,
	'gravityforms_delete_entries' => false,
	'gravityforms_view_settings' => false,
	'gravityforms_edit_settings' => false,
	'gravityforms_export_entries' => false,
	'gravityforms_view_entry_notes' => false,
	'gravityforms_edit_entry_notes' => false,
	]
	]
	];

	foreach ($roles as $role_name => $role_data) {
		add_role($role_name, $role_data['name'], $role_data['capabilities']);
	}
}

add_action('init', 'add_custom_roles');

// Remove custom roles upon plugin deactivation
function remove_custom_roles() {
	remove_role('destination');
	remove_role('travel_manager');
	remove_role('tfs_staff');
}

register_deactivation_hook(__FILE__, 'remove_custom_roles');

// Add custom user meta fields to the user profile pages
function add_custom_user_meta_field($user) {
	if (!in_array('subscriber', (array) $user->roles)) { ?>
   <h3><?php esc_html_e('Custom Redirect URL', 'custom-user-meta'); ?></h3>
   <table class="form-table">
     <tr>
       <th><label for="custom_redirect_url"><?php esc_html_e('Redirect URL'); ?></label></th>
       <td>
         <input type="text" name="custom_redirect_url" id="custom_redirect_url" value="<?php echo esc_attr(get_user_meta($user->ID, 'custom_redirect_url', true)); ?>" class="regular-text" /><br />
         <span class="description"><?php esc_html_e('Enter the URL to which you want to redirect this user upon login.'); ?></span>
       </td>
     </tr>
   </table>
   <h3><?php esc_html_e('Additional Information', 'custom-user-meta'); ?></h3>
   <table class="form-table">
     <tr>
       <th><label for="destination_represent"><?php esc_html_e('Destination Represent'); ?></label></th>
       <td>
         <input type="text" name="destination_represent" id="destination_represent" value="<?php echo esc_attr(get_user_meta($user->ID, 'destination_represent', true)); ?>" class="regular-text" /><br />
         <span class="description"><?php esc_html_e('Enter the destination you represent.'); ?></span>
       </td>
     </tr>
   </table>
	<?php }
}

add_action('show_user_profile', 'add_custom_user_meta_field');
add_action('edit_user_profile', 'add_custom_user_meta_field');

// Save the custom user meta field value
function save_custom_user_meta_field($user_id) {
	if (!current_user_can('edit_user', $user_id)) return false;
	if (isset($_POST['custom_redirect_url'])) {
		$updated = update_user_meta($user_id, 'custom_redirect_url', sanitize_text_field($_POST['custom_redirect_url']));
		if (!$updated) {
			error_log('Failed to update custom_redirect_url for user ID: ' . $user_id);
		}
	}

	/*if (isset($_POST['destination_represent'])) {
		$updated = update_user_meta($user_id, 'destination_represent', sanitize_text_field($_POST['destination_represent']));
		if (!$updated) {
			error_log('Failed to update destination_represent for user ID: ' . $user_id);
		}
	}*/
}

add_action('personal_options_update', 'save_custom_user_meta_field');
add_action('edit_user_profile_update', 'save_custom_user_meta_field');

// Redirect users on login based on their custom user meta field
function redirect_custom_user_on_login($redirect_to, $request, $user) {
	if (isset($user->roles) && is_array($user->roles)) {
		// error_log('User roles: ' . print_r($user->roles, true)); // Comment out post-debugging
		if (in_array('destination', $user->roles) || in_array('travel_manager', $user->roles) || in_array('tfs_staff', $user->roles)) {
			$custom_redirect_url = get_user_meta($user->ID, 'custom_redirect_url', true);
			// error_log('Custom Redirect URL: ' . $custom_redirect_url); // Comment out post-debugging
			if ($custom_redirect_url) {
        $validated_url = wp_validate_redirect($custom_redirect_url, $redirect_to);
        if ($validated_url) {
          return $validated_url;
        }
			}
		}
	}
	return $redirect_to;
}

add_filter('login_redirect', 'redirect_custom_user_on_login', 10, 3);

// Add custom dashboard widget for certain roles
function add_custom_dashboard_widget() {
	if (current_user_can('destination') || current_user_can('travel_manager')) {
		wp_add_dashboard_widget(
		'custom_dashboard_widget',
		'Your Private Page',
		'display_custom_dashboard_widget_content'
		);
	}
}

add_action('wp_dashboard_setup', 'add_custom_dashboard_widget');

function display_custom_dashboard_widget_content() {
	$user_id = get_current_user_id();
	$custom_redirect_url = get_user_meta($user_id, 'custom_redirect_url', true);
	if ($custom_redirect_url) {
		$page_id = url_to_postid($custom_redirect_url);
		$page_title = get_the_title($page_id);
		echo '<p>You have access to the following private page:</p>';
		echo '<p><strong>Title:</strong> ' . esc_html($page_title) . '</p>';
		echo '<p><strong>Link:</strong> <a href="' . esc_url($custom_redirect_url) . '">' . esc_html($custom_redirect_url) . '</a></p>';
	} else {
		echo '<p>No private page assigned yet.</p>';
	}
}

// Remove default dashboard widgets for 'destination' role
function remove_default_dashboard_widgets() {
	if (current_user_can('destination')) {
		remove_meta_box('dashboard_activity', 'dashboard', 'normal');
		remove_meta_box('dashboard_primary', 'dashboard', 'side');
	}
}

add_action('wp_dashboard_setup', 'remove_default_dashboard_widgets', 20);

// Remove the toolbar option for certain roles
function remove_toolbar_option() {
	if (current_user_can('administrator') || current_user_can('super_admin')) {
		return;
	}
	if (current_user_can('destination') || current_user_can('tfs_staff')) {
		add_filter('show_admin_bar', '__return_false');
	}
}

add_action('after_setup_theme', 'remove_toolbar_option');

// Redirect specific travel forms to login if the user is not logged in
function redirect_travel_form_to_login_wp_hook() {
	if (!is_user_logged_in() && (strpos($_SERVER['REQUEST_URI'], '/travel-form/') === 0 || $_SERVER['REQUEST_URI'] === '/travel-form')) {
		wp_safe_redirect(wp_login_url());
		exit;
	}
}

add_action('template_redirect', 'redirect_travel_form_to_login_wp_hook');